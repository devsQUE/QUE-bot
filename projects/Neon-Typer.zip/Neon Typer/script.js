// --- CONSTANTS ---
const WORDS = [
    "SYSTEM", "DATA", "NODE", "GRID", "LASER", "NEON", "CYBER", "VAPOR", "SYNTH",
    "LOGIC", "CODE", "HACK", "ROOT", "ADMIN", "USER", "SHELL", "BASH", "PIXEL",
    "VOXEL", "MATRIX", "FLUX", "WAVE", "PULSE", "CORE", "RAM", "DRIVE", "BIOS",
    "KERNEL", "LINUX", "JAVA", "SCRIPT", "HTML", "CSS", "REACT", "VUE", "NODEJS",
    "SERVER", "CLIENT", "PROXY", "TOKEN", "KEY", "LOCK", "CRYPTO", "HASH", "SALT",
    "VECTOR", "IMAGE", "AUDIO", "VIDEO", "RENDER", "SHADER", "GLOW", "ALPHA", "NET",
    "WEB", "CLOUD", "EDGE", "STACK", "HEAP", "QUEUE", "CACHE", "BUFFER", "PING",
    "PACKET", "ROUTE", "SWITCH", "BRIDGE", "PORT", "SOCKET", "PROTOCOL", "TCP",
    "UDP", "HTTP", "HTTPS", "FTP", "SSH", "TELNET", "SMTP", "IMAP", "POP3", "DNS",
    "DHCP", "LAN", "WAN", "VPN", "HOST", "DOMAIN", "URL", "URI", "PATH", "FILE",
    "FOLDER", "DIR", "MOUNT", "DISK", "TAPE", "REEL", "CHIP", "BOARD", "CIRCUIT",
    "WIRE", "FUSE", "SPARK", "BOLT", "ARC", "VOLT", "WATT", "OHM", "AMP", "HERTZ",
    "FREQ", "GAIN", "NOISE", "STATIC", "GLITCH", "BUG", "PATCH", "FIX", "BUILD",
    "COMPILE", "DEPLOY", "DEBUG", "TRACE", "LOG", "INFO", "WARN", "ERROR", "FATAL",
    "EXIT", "KILL", "STOP", "START", "REBOOT", "RESET", "INIT", "SETUP", "CONFIG",
    "PREF", "SETTING", "OPTION", "FLAG", "PARAM", "ARG", "VAR", "CONST", "LET",
    "INT", "FLOAT", "CHAR", "STRING", "BOOL", "VOID", "NULL", "UNDEFINED", "NAN",
    "TRUE", "FALSE", "IF", "ELSE", "FOR", "WHILE", "LOOP", "BREAK", "RETURN", "IMPORT",
    "EXPORT", "MODULE", "CLASS", "OBJECT", "METHOD", "FUNC", "LAMBDA", "CLOSURE",
    "SCOPE", "THIS", "SELF", "SUPER", "META", "BETA", "OMEGA", "DELTA", "SIGMA",
    "THETA", "GAMMA", "ZETA", "ITER", "INDEX", "CURSOR", "POINTER", "REF", "VALUE",
    "TYPE", "CAST", "PARSE", "STRIP", "SPLIT", "JOIN", "MERGE", "FORK", "CLONE",
    "FETCH", "AXIOS", "AJAX", "JSON", "XML", "YAML", "CSV", "SQL", "NOSQL", "MONGO",
    "REDIS", "QUERY", "TABLE", "ROW", "COL", "FIELD", "VIEW", "INDEX", "STORE", "STATE",
    "PROP", "ATTR", "TAG", "ELEM", "DOM", "BOM", "API", "SDK", "LIB", "BIN", "EXE", "PKG",
    "APP", "SOFT", "FIRM", "WARE", "ANDROID", "IOS", "MAC", "WIN", "UNIX", "CMD", "POWERSHELL",
    "TERMINAL", "CONSOLE", "INPUT", "OUTPUT", "STDIN", "STDOUT", "STDERR", "PIPE", "GREP", "SED",
    "AWK", "FIND", "LOCATE", "CHMOD", "CHOWN", "SUDO", "APT", "YUM", "BREW", "NPM", "YARN",
    "PIP", "GEM", "DOCKER", "KUBE", "POD", "CONTAINER", "VM", "VBOX", "EMU"
];


// --- GAME STATE ---
const state = {
    active: false,
    score: 0,
    lives: 100,
    level: 1,
    words: [],
    lastTime: 0,
    spawnTimer: 0,
    spawnRate: 2000,
    speed: 1,
    mode: 'words',
    difficulty: 1
};

// --- DOM ELEMENTS ---
const els = {
    stage: document.getElementById('game-stage'),
    input: document.getElementById('player-input'),
    overlay: document.getElementById('ui-overlay'),
    startMenu: document.getElementById('menu-start'),
    gameOverMenu: document.getElementById('menu-gameover'),
    score: document.getElementById('score-display'),
    lives: document.getElementById('lives-display'),
    level: document.getElementById('level-display'),
    finalScore: document.getElementById('final-score'),
    body: document.body
};

// --- CORE LOGIC ---
function generateWord() {
    const r = Math.random();
    if (state.mode === 'hex') {
        return '#' + Math.floor(Math.random() * 16777215).toString(16).toUpperCase().padEnd(6, '0').substring(0, 4);
    } else if (state.mode === 'mixed') {
        if (r > 0.6) return Math.floor(Math.random() * 9999).toString();
        if (r > 0.9) return 'X-' + Math.floor(Math.random() * 99).toString();
    }
    return WORDS[Math.floor(Math.random() * WORDS.length)];
}

function createWordEntity() {
    const text = generateWord();
    const el = document.createElement('div');
    el.className = 'word-entity';
    el.innerText = text;

    // Random X position (keep within bounds)
    const stageWidth = els.stage.offsetWidth;
    const x = Math.random() * (stageWidth - 150) + 20;

    el.style.left = `${x}px`;
    el.style.top = `-50px`;

    els.stage.appendChild(el);

    state.words.push({
        el: el,
        text: text,
        x: x,
        y: -50,
        speed: (state.speed + (Math.random() * 0.5)) * state.difficulty
    });
}

function gameLoop(timestamp) {
    if (!state.active) return;

    const deltaTime = timestamp - state.lastTime;
    state.lastTime = timestamp;

    // Spawning
    state.spawnTimer += deltaTime;
    if (state.spawnTimer > state.spawnRate) {
        createWordEntity();
        state.spawnTimer = 0;
    }

    // Movement & Collision
    const deathLine = els.stage.offsetHeight - 30; // Bottom of screen

    // Reverse loop to allow splicing
    for (let i = state.words.length - 1; i >= 0; i--) {
        let w = state.words[i];
        w.y += w.speed;
        w.el.style.top = `${w.y}px`;

        // Hit Bottom
        if (w.y > deathLine) {
            takeDamage(20);
            removeWord(i);
        }
    }

    requestAnimationFrame(gameLoop);
}

function takeDamage(amount) {
    state.lives -= amount;
    updateHUD();

    // Visual FX
    els.body.classList.add('shake-screen');
    els.stage.style.boxShadow = "inset 0 -100px 100px rgba(255,0,85,0.5)";

    setTimeout(() => {
        els.body.classList.remove('shake-screen');
        els.stage.style.boxShadow = "none";
    }, 300);

    // Input Penalty
    els.input.value = '';
    clearHighlights();

    if (state.lives <= 0) gameOver();
}

function removeWord(index) {
    if (state.words[index]) {
        state.words[index].el.remove();
        state.words.splice(index, 1);
    }
}

function clearHighlights() {
    state.words.forEach(w => w.el.classList.remove('highlight'));
}

function updateHUD() {
    els.score.innerText = Math.floor(state.score);
    els.lives.innerText = Math.max(0, state.lives) + '%';
    els.level.innerText = state.level;

    // Life color change
    if (state.lives > 50) els.lives.style.color = "var(--neon-cyan)";
    else if (state.lives > 20) els.lives.style.color = "var(--neon-yellow)";
    else els.lives.style.color = "var(--neon-pink)";
}

// --- PARTICLE SYSTEM ---
function explode(x, y, color) {
    const particleCount = 15;
    for (let i = 0; i < particleCount; i++) {
        const p = document.createElement('div');
        p.classList.add('particle');
        els.stage.appendChild(p);

        const size = Math.random() * 4 + 2;
        p.style.width = `${size}px`;
        p.style.height = `${size}px`;
        p.style.background = color;
        p.style.left = `${x}px`;
        p.style.top = `${y}px`;

        // Physics for particle
        const angle = Math.random() * Math.PI * 2;
        const velocity = Math.random() * 5 + 2;
        let dx = Math.cos(angle) * velocity;
        let dy = Math.sin(angle) * velocity;

        let life = 1;

        const animateParticle = () => {
            life -= 0.05;
            if (life <= 0) {
                p.remove();
            } else {
                const curX = parseFloat(p.style.left);
                const curY = parseFloat(p.style.top);
                p.style.left = `${curX + dx}px`;
                p.style.top = `${curY + dy}px`;
                p.style.opacity = life;
                requestAnimationFrame(animateParticle);
            }
        };
        requestAnimationFrame(animateParticle);
    }
}

// --- INPUT HANDLING ---
els.input.addEventListener('input', (e) => {
    const val = e.target.value.toUpperCase();

    // 1. Highlight matching words
    let hasMatch = false;
    state.words.forEach(w => {
        if (w.text.startsWith(val)) {
            w.el.classList.add('highlight');
            hasMatch = true;
        } else {
            w.el.classList.remove('highlight');
        }
    });

    // 2. Check for completion
    const exactMatchIndex = state.words.findIndex(w => w.text === val);

    if (exactMatchIndex !== -1) {
        // Success!
        const w = state.words[exactMatchIndex];

        // Score Math
        const points = 10 * state.difficulty * state.level;
        state.score += points;

        // Level Up Logic
        if (state.score > state.level * 250) {
            state.level++;
            state.spawnRate = Math.max(500, state.spawnRate - 150);
            state.speed += 0.2;
        }

        // FX
        explode(parseFloat(w.el.style.left) + 20, w.y + 10, 'var(--neon-cyan)');

        removeWord(exactMatchIndex);
        els.input.value = ''; // Clear input
        clearHighlights();
        updateHUD();
    }
});

// --- CONTROL ---
function startGame() {
    // Get Settings
    state.mode = document.querySelector('input[name="mode"]:checked').value;
    state.difficulty = parseFloat(document.querySelector('input[name="difficulty"]:checked').value);

    // Reset State
    state.score = 0;
    state.lives = 100;
    state.level = 1;
    state.spawnRate = 2000 / state.difficulty;
    state.speed = 1.5;
    state.words.forEach(w => w.el.remove());
    state.words = [];

    updateHUD();

    // UI
    els.startMenu.classList.add('hidden');
    els.overlay.classList.add('hidden');
    els.input.value = '';
    els.input.focus();

    state.active = true;
    state.lastTime = performance.now();
    requestAnimationFrame(gameLoop);
}

function gameOver() {
    state.active = false;
    els.finalScore.innerText = Math.floor(state.score);
    els.overlay.classList.remove('hidden');
    els.gameOverMenu.classList.remove('hidden');
    els.startMenu.classList.add('hidden');
}

function resetGame() {
    els.gameOverMenu.classList.add('hidden');
    els.startMenu.classList.remove('hidden');
}

// Auto focus input if clicking anywhere on background
document.addEventListener('click', (e) => {
    if (state.active && !e.target.closest('button')) {
        els.input.focus();
    }
});
